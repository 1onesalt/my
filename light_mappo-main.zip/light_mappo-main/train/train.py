"""
# @Time    : 2021/6/30 10:07 下午
# @Author  : hezhiqiang
# @Email   : tinyzqh@163.com
# @File    : train.py
"""

# !/usr/bin/env python
import sys
import os
import socket
import setproctitle
import numpy as np
from pathlib import Path
import torch
from gym import spaces
# Get the parent directory of the current file
parent_dir = os.path.abspath(os.path.join(os.getcwd(), "."))
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# # Append the parent directory to sys.path, otherwise the following import will fail
# sys.path.append(parent_dir)

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import get_config
from envs.env_wrappers import DummyVecEnv
from MY_ENV.envs.target_search import TargetSearchEnv
from MY_ENV.envs.my_wrappers import FlattenObservation

"""Train script for MPEs."""

#先到return DummyVecEnv，DummyVecEnv调用get_env_fn(i)函数才进入，进入后return init_env 并没有实例化函数
#因此是先直接跳过，最终env是通过传入的参数get_env_fn(i)来得到不同的env的

# DummyVecEnv 的参数是一个函数列表，每个函数是 get_env_fn(i)，返回 init_env。
# 此时并没有真正实例化环境，只是把创建环境的函数（init_env）传递给了 DummyVecEnv。
# 只有在 DummyVecEnv 内部需要用到环境时，才会调用这些 init_env 函数，真正实例化环境对象。
def make_train_env(all_args):
    def get_env_fn(rank):
        def init_env():

            if all_args.env_name == "MyEnv":
                env = TargetSearchEnv(
                    n_agent=all_args.num_agents,
                    max_steps=all_args.episode_length,
                    # 如果需要，这里可以传入更多参数，如 x_min, x_max 等
                )
                env = FlattenObservation(env)
            else:
                print("Can not support the " + all_args.env_name + " environment.")
                raise NotImplementedError
            
            # from envs.env_discrete import DiscreteActionEnv
            # env = DiscreteActionEnv()  #创建环境，告诉环境动作空间维度、观测维度、共享观测维度

            env.seed(all_args.seed + rank * 1000)
            return env

        return init_env  

    return DummyVecEnv([get_env_fn(i) for i in range(all_args.n_rollout_threads)])  #封装n_rollout_threads线程数


def make_eval_env(all_args):
    def get_env_fn(rank):
        def init_env():
            if all_args.env_name == "MyEnv":
                # [修改] 实例化评估环境
                env = TargetSearchEnv(
                    n_agent=all_args.num_agents,
                    max_steps=all_args.episode_length
                )
                env = FlattenObservation(env)
            else:
                print("Can not support the " + all_args.env_name + " environment.")
                raise NotImplementedError

            # from envs.env_discrete import DiscreteActionEnv
            # env = DiscreteActionEnv()


            env.seed(all_args.seed + rank * 1000)
            return env

        return init_env

    return DummyVecEnv([get_env_fn(i) for i in range(all_args.n_eval_rollout_threads)])


def parse_args(args, parser):
    parser.add_argument("--scenario_name", type=str, default="MyEnv", help="Which scenario to run on")
    parser.add_argument("--num_landmarks", type=int, default=3)
    parser.add_argument("--num_agents", type=int, default=2, help="number of players")

    all_args = parser.parse_known_args(args)[0]

    return all_args


def main(args):
    parser = get_config()
    all_args = parse_args(args, parser)

    if all_args.algorithm_name == "rmappo":
        assert all_args.use_recurrent_policy or all_args.use_naive_recurrent_policy, "check recurrent policy!"
    elif all_args.algorithm_name == "mappo":
        assert (
            all_args.use_recurrent_policy == False and all_args.use_naive_recurrent_policy == False  #不用rmappo，那么所有循环神经网络的参数都要等于false
        ), "check recurrent policy!"
    else:
        raise NotImplementedError

    assert (
        all_args.share_policy == True and all_args.scenario_name == "simple_speaker_listener"
    ) == False, "The simple_speaker_listener scenario can not use shared policy. Please check the config.py."

    # cuda
    if all_args.cuda and torch.cuda.is_available():
        print("choose to use gpu...")
        device = torch.device("cuda:0")
        torch.set_num_threads(all_args.n_training_threads)
        if all_args.cuda_deterministic:
            torch.backends.cudnn.benchmark = False
            torch.backends.cudnn.deterministic = True
    else:
        print("choose to use cpu...")
        device = torch.device("cpu")
        torch.set_num_threads(all_args.n_training_threads)  #设置训练进程

    # run dir 保存结果的路径目录，注意：检查一下
    run_dir = (
        Path(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0] + "/results")
        / all_args.env_name
        / all_args.scenario_name
        / all_args.algorithm_name
        / all_args.experiment_name
    )
    if not run_dir.exists():
        os.makedirs(str(run_dir))

    if not run_dir.exists():
        curr_run = "run1"
    else:
        exst_run_nums = [
            int(str(folder.name).split("run")[1])
            for folder in run_dir.iterdir()
            if str(folder.name).startswith("run")
        ]
        if len(exst_run_nums) == 0:
            curr_run = "run1"
        else:
            curr_run = "run%i" % (max(exst_run_nums) + 1)
    run_dir = run_dir / curr_run
    if not run_dir.exists():
        os.makedirs(str(run_dir))

    setproctitle.setproctitle(
        str(all_args.algorithm_name)
        + "-"
        + str(all_args.env_name)
        + "-"
        + str(all_args.experiment_name)
        + "@"
        + str(all_args.user_name)
    )

    # seed随机种子
    torch.manual_seed(all_args.seed)
    torch.cuda.manual_seed_all(all_args.seed)
    np.random.seed(all_args.seed)

    # env init
    envs = make_train_env(all_args)  #训练env
    eval_envs = make_eval_env(all_args) if all_args.use_eval else None   #评估env
        
    # 检查 share_observation_space 与实际拼接规则一致
    if all_args.use_centralized_V:
        obs_dim = envs.observation_space[0].shape[0] 
        num_agents = all_args.num_agents
        expected_share_dim = obs_dim * num_agents
        actual_share_dim = envs.share_observation_space[0].shape[0]
        assert actual_share_dim == expected_share_dim, (
            f"share_obs_dim mismatch: got {actual_share_dim}, expected {expected_share_dim}"
        )

        if eval_envs:
            eval_share_dim = eval_envs.share_observation_space[0].shape[0]
            assert eval_share_dim == expected_share_dim, (
                f"eval share_obs_dim mismatch: got {eval_share_dim}, expected {expected_share_dim}"
            )


    num_agents = all_args.num_agents

    config = {
        "all_args": all_args,
        "envs": envs,
        "eval_envs": eval_envs,
        "num_agents": num_agents,
        "device": device,
        "run_dir": run_dir,
    }

    # run experiments
    if all_args.share_policy:
        from runner.shared.env_runner import EnvRunner as Runner  #智能体之间参数是否共享
    else:
        from runner.separated.env_runner import EnvRunner as Runner

    runner = Runner(config)  #这里config里面是有一个实例化的对象envs和eval_envs的，初始化runner
    runner.run()             #实际采数据、交互

    # post process
    envs.close()
    if all_args.use_eval and eval_envs is not envs:
        eval_envs.close()

    runner.writter.export_scalars_to_json(str(runner.log_dir + "/summary.json"))
    runner.writter.close()


if __name__ == "__main__":
    main(sys.argv[1:])
